import fs from "node:fs/promises";

export default class Loader {
  constructor(client) {
    this.client = client
  }

  async loadCommands() {
    const categories = await fs.readdir('./commands');
    for (const cate of categories) {
      if (cate.startsWith('.')) continue;
      if (cate.startsWith('.')) continue;
      const folder = await fs.readdir(`./commands/${cate}`);
      for (let file of folder) {
        if (!file.endsWith('.js')) continue;
        const module = await import(`../commands/${cate}/${file}`);
        const command =
            typeof module.default === "function"
                ? new module.default()
                : module.default;

        if (!command.name) throw new Error(`${file} has no command name.`);

        command.category = cate;
        this.client.commands.set(command.name, command);
        console.log(`Loaded: ${command.name}`);

        if (command.slash && command.data) this.client.slashCommands.push(command.data.toJSON());
      }
    }
  }

  async loadEvents() {
  const categories = await fs.readdir("./events");

  for (const cate of categories) {
    const folder = await fs.readdir(`./events/${cate}`);

    for (const file of folder) {
      const module = await import(`../events/${cate}/${file}`);

      const event =
        typeof module.default === "function"
          ? new module.default()
          : module.default;

      if (!event.name)
        throw new Error(`${file} has no event name.`);

      const listener = (...args) => event.execute(...args, this.client);

      if (event.once) {
        this.client.once(event.name, listener);
      } else {
        this.client.on(event.name, listener);
      }

      console.log(`Loaded Event: ${event.name}`);
    }
  }
}
}