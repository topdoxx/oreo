import {SlashCommandBuilder} from "discord.js";

export default class Command{
  constructor(options = {}) {
    this.name = options.name;
    this.aliases = options.aliases ?? [];
    this.description = options.description ?? "None";
    this.slash = options.slash ?? false;
    this.ownerOnly = options.ownerOnly ?? false;
    this.permissions = options.permissions ?? [];
    this.options = options.options ?? [];

    this.data = options.data ?? new SlashCommandBuilder().setName(this.name).setDescription(this.description)
  }

  async execute(client, message, args) {}
  async slashExecute(client, interaction) {}
}