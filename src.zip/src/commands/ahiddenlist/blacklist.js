import Command from "../../structure/Command.js";
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from "discord.js";
import { Tick, Cross, Warn } from "../../utils/emojis.js";

export default class BlacklistCommand extends Command {
  constructor() {
    super({
      name: "blacklist",
      aliases: ["bl"],
      description: "Manage blacklisted users and servers (Developer only)",
      slash: false
    });
  }

  async execute(client, message, args) {
    if (!client.developers?.includes(message.author.id)) return;

    const type = args[0]?.toLowerCase();
    const action = args[1]?.toLowerCase();

    if (type === "user") {
      if (action === "add") {
        const targetId = args[2]?.replace(/[<@!>]/g, "");
        if (!targetId || !/^\d{17,20}$/.test(targetId)) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Cross} Please provide a valid User ID to blacklist.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        if (client.developers.includes(targetId)) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Cross} You cannot blacklist a bot developer.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const reason = args.slice(3).join(" ") || "No reason provided";
        client.db.blacklistUser(targetId, reason);

        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Tick} Successfully blacklisted user \`${targetId}\`.\nReason: **${reason}**`)
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }

      if (action === "remove" || action === "delete") {
        const targetId = args[2]?.replace(/[<@!>]/g, "");
        if (!targetId || !/^\d{17,20}$/.test(targetId)) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Cross} Please provide a valid User ID to unblacklist.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const removed = client.db.unblacklistUser(targetId);
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              removed
                ? `${Tick} Successfully removed user \`${targetId}\` from blacklist.`
                : `${Warn} User \`${targetId}\` was not blacklisted.`
            )
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }

      if (action === "list") {
        const users = client.db.getBlacklistedUsers();
        if (!users.length) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Warn} There are currently no blacklisted users.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const listText = users
          .slice(0, 20)
          .map((u, i) => `${i + 1}. \`${u.user_id}\` • ${u.reason || "No reason"}`)
          .join("\n");

        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `# Blacklisted Users (${users.length})\n${listText}${users.length > 20 ? `\n...and ${users.length - 20} more` : ""}`
            )
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }
    }

    if (type === "server" || type === "guild") {
      if (action === "add") {
        const targetId = args[2];
        if (!targetId || !/^\d{17,20}$/.test(targetId)) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Cross} Please provide a valid Server ID to blacklist.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const reason = args.slice(3).join(" ") || "No reason provided";
        client.db.blacklistGuild(targetId, reason);

        const targetGuild = client.guilds.cache.get(targetId);
        if (targetGuild) {
          await targetGuild.leave().catch(() => {});
        }

        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Tick} Successfully blacklisted server \`${targetId}\`${targetGuild ? ` (${targetGuild.name}) and left it` : ""}.\nReason: **${reason}**`
            )
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }

      if (action === "remove" || action === "delete") {
        const targetId = args[2];
        if (!targetId || !/^\d{17,20}$/.test(targetId)) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Cross} Please provide a valid Server ID to unblacklist.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const removed = client.db.unblacklistGuild(targetId);
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              removed
                ? `${Tick} Successfully removed server \`${targetId}\` from blacklist.`
                : `${Warn} Server \`${targetId}\` was not blacklisted.`
            )
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }

      if (action === "list") {
        const guilds = client.db.getBlacklistedGuilds();
        if (!guilds.length) {
          const container = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(`${Warn} There are currently no blacklisted servers.`)
            );
          return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
        }

        const listText = guilds
          .slice(0, 20)
          .map((g, i) => `${i + 1}. \`${g.guild_id}\` • ${g.reason || "No reason"}`)
          .join("\n");

        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `# Blacklisted Servers (${guilds.length})\n${listText}${guilds.length > 20 ? `\n...and ${guilds.length - 20} more` : ""}`
            )
          );
        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      }
    }

    const helpContainer = new ContainerBuilder()
      .setAccentColor(client.theme)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `${Warn} Usage:\n` +
          `\`,blacklist user <add|remove|list> [userId] [reason]\`\n` +
          `\`,blacklist server <add|remove|list> [guildId] [reason]\``
        )
      );
    return message.reply({ components: [helpContainer], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
  }
}

