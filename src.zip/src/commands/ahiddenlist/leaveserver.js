import Command from "../../structure/Command.js";
import { MessageFlags, ContainerBuilder, TextDisplayBuilder } from "discord.js";
import { Tick, Cross, Warn } from "../../utils/emojis.js";

export default class LeaveServerCommand extends Command {
  constructor() {
    super({
      name: "leaveserver",
      aliases: ["leaveguild", "gleave"],
      description: "Leave a server by ID or current server (Developer only)",
      slash: false
    });
  }

  async execute(client, message, args) {
    if (!client.developers?.includes(message.author.id)) return;

    const guildId = args[0] || message.guild?.id;

    if (!guildId) {
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Cross} Please provide a server ID to leave.`)
        );
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    }

    const guild = client.guilds.cache.get(guildId);
    if (!guild) {
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Cross} I am not in a server with ID \`${guildId}\`.`)
        );
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    }

    const guildName = guild.name;
    const isCurrent = message.guild?.id === guild.id;

    if (!isCurrent) {
      await guild.leave().catch((err) => {
        console.error("Failed to leave guild:", err);
      });

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} Successfully left server **${guildName}** (\`${guildId}\`).`)
        );
      return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } else {
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} Leaving **${guildName}** now. Bye!`)
        );
      await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      await guild.leave().catch((err) => {
        console.error("Failed to leave current guild:", err);
      });
    }
  }
}

