import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick, Cross, Warn } from "../../utils/emojis.js";
import db from "../../utils/database.js";

export default class UnlikeCommand extends Command {
  constructor() {
    super({
      name: "unlike",
      aliases: ["unfav", "dislike"],
      description: "Remove a song from your liked songs library",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("unlike")
        .setDescription("Remove a song from your liked songs library")
        .addStringOption((opt) =>
          opt
            .setName("query")
            .setDescription("Song title or link to remove (leave empty for current playing)")
            .setRequired(false)
        )
    });
  }

  async execute(client, message, args) {
    try {
      let query = args.join(" ");
      if (!query) {
        const player = client.riffy?.players.get(message.guild.id);
        if (player && player.current) {
          query = player.current.info.uri;
        }
      }

      if (!query) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Please specify a song title/link or play a song to unlike.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const removed = db.removeLikedSong(message.author.id, query);
      if (!removed) {
        const notFoundContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Warn} Could not find \`${query}\` in your liked songs.`
            )
          );
        return message.reply({
          components: [notFoundContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Removed song matching \`${query}\` from your liked songs library.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      let query = interaction.options.getString("query");
      if (!query) {
        const player = client.riffy?.players.get(interaction.guild.id);
        if (player && player.current) {
          query = player.current.info.uri;
        }
      }

      if (!query) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Please specify a song title/link or play a song to unlike.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const removed = db.removeLikedSong(interaction.user.id, query);
      if (!removed) {
        const notFoundContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Warn} Could not find \`${query}\` in your liked songs.`
            )
          );
        return interaction.reply({
          components: [notFoundContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Removed song matching \`${query}\` from your liked songs library.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
