import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Play, Warn, Music } from "../../utils/emojis.js";
import { formatTime, checkVoice } from "../../utils/musicHelper.js";
import { paginator } from "../../utils/Paginator.js";
import db from "../../utils/database.js";

export default class LikedCommand extends Command {
  constructor() {
    super({
      name: "liked",
      aliases: ["likedsongs", "favorites"],
      description: "View or play your liked songs library",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("liked")
        .setDescription("View or play your liked songs library")
        .addBooleanOption((opt) =>
          opt
            .setName("play")
            .setDescription("Play all your liked songs into queue")
            .setRequired(false)
        )
    });
  }

  generatePages(likedSongs) {
    const pageSize = 10;
    const totalPages = Math.max(1, Math.ceil(likedSongs.length / pageSize));
    const pages = [];

    for (let p = 0; p < totalPages; p++) {
      const start = p * pageSize;
      const songsOnPage = likedSongs.slice(start, start + pageSize);

      let text = `## Liked Songs\n`;
      const lines = songsOnPage.map((s, i) => {
        const pos = start + i + 1;
        return `${pos}. [${s.title}](${s.uri}) • \`${formatTime(s.length)}\``;
      });

      text += lines.join("\n");
      text += `\n\n-# Showing page ${p + 1}/${totalPages}`;
      pages.push(text);
    }

    return pages;
  }

  async execute(client, message, args) {
    try {
      const likedSongs = db.getLikedSongs(message.author.id);
      if (!likedSongs || likedSongs.length === 0) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Warn} You don't have any liked songs yet. Use \`,like\` while playing a song to save it!`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const shouldPlay = args[0]?.toLowerCase() === "play";

      if (shouldPlay) {
        const voiceCheck = checkVoice(client, message.member);
        if (!voiceCheck.ok) {
          return message.reply({
            components: [voiceCheck.container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] }
          });
        }

        let player = client.riffy.players.get(message.guild.id);
        if (!player) {
          player = client.riffy.createConnection({
            guildId: message.guild.id,
            voiceChannel: voiceCheck.channel.id,
            textChannel: message.channel.id,
            deaf: true
          });
        }

        let addedCount = 0;
        for (const s of likedSongs) {
          try {
            const res = await client.riffy.resolve({ query: s.uri, source: "amsearch", requester: message.author });
            if (res && res.tracks && res.tracks[0]) {
              res.tracks[0].info.requester = message.author;
              player.queue.add(res.tracks[0]);
              addedCount++;
            }
          } catch { }
        }

        if (!player.playing && !player.paused) await player.play();

        const playContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Play} Queued **${addedCount}** songs from your liked library.`
            )
          );

        return message.reply({
          components: [playContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const pages = this.generatePages(likedSongs);
      await paginator(message, pages);
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const likedSongs = db.getLikedSongs(interaction.user.id);
      if (!likedSongs || likedSongs.length === 0) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Warn} You don't have any liked songs yet. Use \`/like\` while playing a song to save it!`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const shouldPlay = interaction.options.getBoolean("play") ?? false;

      if (shouldPlay) {
        const voiceCheck = checkVoice(client, interaction.member);
        if (!voiceCheck.ok) {
          return interaction.reply({
            components: [voiceCheck.container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] }
          });
        }

        let player = client.riffy.players.get(interaction.guild.id);
        if (!player) {
          player = client.riffy.createConnection({
            guildId: interaction.guild.id,
            voiceChannel: voiceCheck.channel.id,
            textChannel: interaction.channel.id,
            deaf: true
          });
        }

        let addedCount = 0;
        for (const s of likedSongs) {
          try {
            const res = await client.riffy.resolve({ query: s.uri, source: "amsearch", requester: interaction.user });
            if (res && res.tracks && res.tracks[0]) {
              res.tracks[0].info.requester = interaction.user;
              player.queue.add(res.tracks[0]);
              addedCount++;
            }
          } catch { }
        }

        if (!player.playing && !player.paused) await player.play();

        const playContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Play} Queued **${addedCount}** songs from your liked library.`
            )
          );

        return interaction.reply({
          components: [playContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const pages = this.generatePages(likedSongs);
      await paginator(interaction, pages);
    } catch (e) {
      console.log(e);
    }
  }
}
