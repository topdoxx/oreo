import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Warn, Tick } from "../../utils/emojis.js";
import db from "../../utils/database.js";

export default class LikeCommand extends Command {
  constructor() {
    super({
      name: "like",
      aliases: ["favorite", "fav"],
      description: "Add the currently playing track to your liked songs",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("like")
        .setDescription("Add the currently playing track to your liked songs")
    });
  }

  async execute(client, message, args) {
    try {
      const player = client.riffy?.players.get(message.guild.id);
      if (!player || !player.current) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no track currently playing to like.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const track = player.current;
      const uri = track.info?.uri || "";
      const alreadyLiked = db.isLiked(message.author.id, uri);

      if (alreadyLiked) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} This song is already in your liked songs!`)
          );
        return message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      db.addLikedSong(message.author.id, track);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Added [${track.info.title}](${uri}) to your liked songs library.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const player = client.riffy?.players.get(interaction.guild.id);
      if (!player || !player.current) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no track currently playing to like.`)
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const track = player.current;
      const uri = track.info?.uri || "";
      const alreadyLiked = db.isLiked(interaction.user.id, uri);

      if (alreadyLiked) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} This song is already in your liked songs!`)
          );
        return interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      db.addLikedSong(interaction.user.id, track);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Added [${track.info.title}](${uri}) to your liked songs library.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
