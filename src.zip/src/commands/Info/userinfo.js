import Command from "../../structure/Command.js";
import {MessageFlags, ContainerBuilder, TextDisplayBuilder, SectionBuilder, SeparatorBuilder, SeparatorSpacingSize, ThumbnailBuilder, SlashCommandBuilder} from "discord.js";

const ts = (date) => `<t:${Math.floor(date.getTime() / 1000)}:D>`;

async function MakeContainer(client, member) {
  const user = await member.user.fetch({ force: true });
  const roles = member.roles.cache
    .filter(r => r.id !== member.guild.id)
    .sort((a, b) => b.position - a.position);
  const roleList = roles.map(r => `<@&${r.id}>`).slice(0, 10);
  const rolesText = roleList.length ? roleList.join(' ') : '`None`';
  const overflow = roles.size > 10 ? ` *+${roles.size - 10} more*` : '';

  const container = new ContainerBuilder().setAccentColor(client.theme)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <@${user.id}>`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addSectionComponents(new SectionBuilder()
      .setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: user.displayAvatarURL({ size: 1024 }) } }))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `**ID:** \`${user.id}\`\n**Username:** \`${user.username}\`\n**Created:** ${ts(user.createdAt)}\n**Joined:** ${ts(member.joinedAt)}`
      )))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `**Roles [${roles.size}]:** ${rolesText}${overflow}`
    ))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ID: ${user.id}`));

  return container;
}

export default class UserInfoCommand extends Command {
  constructor() {
    super({
      name: 'userinfo',
      aliases: ['ui', 'whois'],
      description: 'Shows information about a user',
      slash: true,
      data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Shows information about a user')
        .addUserOption(option =>
          option.setName('user').setDescription('The user to get info of').setRequired(false)
        )
    });
  }

  async execute(client, message, args) {
    try {
      let member = message.mentions.members.first();
      if (!member && args[0]) member = message.guild.members.cache.get(args[0]);
      if (!member) member = message.member;
      const container = await MakeContainer(client, member);
      await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }

  async slashExecute(client, interaction) {
    try {
      const member = interaction.options.getMember('user') ?? interaction.member;
      const container = await MakeContainer(client, member);
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }
}
