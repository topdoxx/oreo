import Command from "../../structure/Command.js";
import { MessageFlags, ContainerBuilder, TextDisplayBuilder, SlashCommandBuilder } from "discord.js";
import { swifi } from "../../utils/emojis.js";

export default class PingCommand extends Command {
  constructor() {
    super({
      name: 'ping',
      aliases: ['latency'],
      description: 'Shows Websocket latency',
      slash: true
    });
  }

  async execute(client, message, args) {
    const container = new ContainerBuilder().setAccentColor(client.theme)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(`${swifi} Websocket latency: \`${client.ws.ping}ms\``));
    await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
  }

  async slashExecute(client, interaction) {
    const container = new ContainerBuilder().setAccentColor(client.theme)
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(`${swifi} Websocket latency: \`${client.ws.ping}ms\``));
    await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
  }
}