import Command from "../../structure/Command.js";
import {MessageFlags, ContainerBuilder, TextDisplayBuilder, SectionBuilder, SeparatorBuilder, SeparatorSpacingSize, ThumbnailBuilder, SlashCommandBuilder} from "discord.js";

const ts = (date) => `<t:${Math.floor(date.getTime() / 1000)}:D>`;

async function MakeContainer(client, guild) {
  const owner = await guild.fetchOwner();
  const iconURL = guild.iconURL({ size: 1024 }) ?? client.user.displayAvatarURL({ size: 1024 });

  const container = new ContainerBuilder().setAccentColor(client.theme)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${guild.name}`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addSectionComponents(new SectionBuilder()
      .setThumbnailAccessory(new ThumbnailBuilder({ description: 'server icon', media: { url: iconURL } }))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `**ID:** \`${guild.id}\`\n**Owner:** <@${owner.id}>\n**Created:** ${ts(guild.createdAt)}\n**Members:** \`${guild.memberCount}\`\n**Channels:** \`${guild.channels.cache.size}\`\n**Roles:** \`${guild.roles.cache.size}\``
      )))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `**Boost Level:** \`${guild.premiumTier}\`\n**Boosts:** \`${guild.premiumSubscriptionCount ?? 0}\`\n**Verification:** \`${guild.verificationLevel}\``
    ))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# ID: ${guild.id}`));

  return container;
}

export default class ServerInfoCommand extends Command {
  constructor() {
    super({
      name: 'serverinfo',
      aliases: ['si', 'guildinfo'],
      description: 'Shows information about the server',
      slash: true,
      data: new SlashCommandBuilder()
        .setName('serverinfo')
        .setDescription('Shows information about the server')
    });
  }

  async execute(client, message, args) {
    try {
      const container = await MakeContainer(client, message.guild);
      await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }

  async slashExecute(client, interaction) {
    try {
      const container = await MakeContainer(client, interaction.guild);
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }
}
