import Command from "../../structure/Command.js";
import { MessageFlags, ContainerBuilder, TextDisplayBuilder, SectionBuilder, SeparatorBuilder, SeparatorSpacingSize, ThumbnailBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, SlashCommandBuilder } from "discord.js";

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  return `${d}d ${h % 24}h ${m % 60}m ${s % 60}s`;
}

async function MakeContainer(client) {
  const memMB = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
  const totalUsers = client.guilds.cache.reduce((acc, g) => acc + g.memberCount, 0);
  const inviteBtn = new ButtonBuilder().setLabel('Invite').setStyle(ButtonStyle.Link).setURL('https://discord.com/oauth2/authorize?client_id=1567215147242496011');
  const supportBtn = new ButtonBuilder().setLabel('Support').setStyle(ButtonStyle.Link).setURL('https://discord.gg/QKzYyUMusV');

  const container = new ContainerBuilder().setAccentColor(client.theme)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${client.user.displayName}`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addSectionComponents(new SectionBuilder()
      .setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: client.user.displayAvatarURL({ size: 1024 }) } }))
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(
        `**Uptime:** \`${formatUptime(client.uptime)}\`\n**Ping:** \`${client.ws.ping}ms\`\n**Guilds:** \`${client.guilds.cache.size}\`\n**Users:** \`${totalUsers}\`\n**Commands:** \`${client.commands.size}\`\n**Memory:** \`${memMB} MB\``
      )))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addActionRowComponents(new ActionRowBuilder().addComponents(inviteBtn, supportBtn))

  return container;
}

export default class BotInfoCommand extends Command {
  constructor() {
    super({
      name: 'botinfo',
      aliases: ['bi', 'bot'],
      description: 'Shows information about the bot',
      slash: true,
      data: new SlashCommandBuilder()
        .setName('botinfo')
        .setDescription('Shows information about the bot')
    });
  }

  async execute(client, message, args) {
    try {
      const container = await MakeContainer(client);
      await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }

  async slashExecute(client, interaction) {
    try {
      const container = await MakeContainer(client);
      await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
    } catch (E) { console.log(E) }
  }
}
