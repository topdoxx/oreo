import Command from "../../structure/Command.js";
import { MessageFlags, ContainerBuilder, TextDisplayBuilder, SectionBuilder, SeparatorBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, SeparatorSpacingSize, ThumbnailBuilder, ComponentType } from "discord.js";
import fs from "node:fs/promises";

export default class HelpCommand extends Command {
  constructor() {
    super({
      name: 'help',
      aliases: ['h'],
      description: 'Shows Help Menu',
      slash: true
    });
  }

  async execute(client, message, args) {
    try {
      const inviteBtn = new ButtonBuilder().setLabel('Invite').setStyle(ButtonStyle.Link).setURL('https://discord.com/oauth2/authorize?client_id=1567215147242496011')
      const supportBtn = new ButtonBuilder().setLabel('Support').setStyle(ButtonStyle.Link).setURL('https://discord.gg/QKzYyUMusV')

      const selectOptions = [];
      const categories = (await fs.readdir('./commands')).filter(
        (c) => c.toLowerCase() !== 'ahiddenlist' && !c.startsWith('.')
      );
      for (const cate of categories) {
        selectOptions.push(
          {
            label: cate,
            value: cate.toLowerCase()
          }
        )
      }

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('help_select')
        .setPlaceholder('Browse Categories')
        .addOptions(selectOptions);

      const row1 = new ActionRowBuilder().addComponents(selectMenu)
      const row2 = new ActionRowBuilder().addComponents(inviteBtn, supportBtn)

      const publicCommands = client.commands.filter(c => c.category?.toLowerCase() !== 'ahiddenlist');
      const container = new ContainerBuilder().setAccentColor(client.theme)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${client.user.displayName}`))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
        .addSectionComponents(new SectionBuilder().setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: client.user.displayAvatarURL({ size: 1024, dynamic: true }) } })).addTextDisplayComponents(new TextDisplayBuilder().setContent
            (`Commands: \`${publicCommands.size}\`\nSlash Commands: \`${client.slashCommands.length}\`\nPrefix: \`${client.defaultPrefix}\`\nWebsocket Latency: \`${client.ws.ping}ms\``)))
        .addActionRowComponents(row1)
        .addActionRowComponents(row2)
      const sent = await message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      const collector = sent.createMessageComponentCollector({
        componentType: ComponentType.StringSelect,
        time: 60000
      });

      collector.on('collect', async (i) => {
        try {
          if (i.user.id !== message.author.id) {
            return i.reply({ content: `This menu is not for you.`, flags: MessageFlags.Ephemeral });
          }
          await i.deferReply({ flags: MessageFlags.Ephemeral });

          const selection = i.values[0];
          const targetCat = categories.find(c => c.toLowerCase() === selection);
          if (targetCat) {
            const categoryCmds = client.commands.filter(c => c.category?.toLowerCase() === targetCat.toLowerCase() && c.name !== 'help');

            let cmdListText = [];
            for (const [name, cmd] of categoryCmds) {
              const slashC = message.guild?.commands?.cache?.find(c => c.name === cmd.name) || client.application?.commands?.cache?.find(c => c.name === cmd.name);
              if (slashC) {
                cmdListText.push(`</${slashC.name}:${slashC.id}> • ${slashC.description || cmd.description}`);
              } else {
                cmdListText.push(`\`${cmd.name}\` • ${cmd.description || "No description"}`);
              }
            }

            let CatContainer = new ContainerBuilder().setAccentColor(client.theme)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${targetCat}`))
              .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(cmdListText.join('\n') || "No commands found."))
              .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# Total commands: ${cmdListText.length}`));
            await i.editReply({ components: [CatContainer], flags: MessageFlags.IsComponentsV2 });
          }
        } catch (err) {
          console.error("Help menu collect error:", err);
        }
      });

      collector.on('end', async () => {
        const publicCmds = client.commands.filter(c => c.category?.toLowerCase() !== 'ahiddenlist');
        const endContainer = new ContainerBuilder().setAccentColor(client.theme)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${client.user.displayName}`))
          .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
          .addSectionComponents(new SectionBuilder().setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: client.user.displayAvatarURL({ size: 1024, dynamic: true }) } })).addTextDisplayComponents(new TextDisplayBuilder().setContent
            (`Commands: \`${publicCmds.size}\`\nSlash Commands: \`${client.slashCommands.length}\`\nPrefix: \`${client.defaultPrefix}\`\nWebsocket Latency: \`${client.ws.ping}ms\``)))
          .addActionRowComponents(new ActionRowBuilder().addComponents(selectMenu.setDisabled(true)))
          .addActionRowComponents(row2)
        await sent.edit({ components: [endContainer], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      });
    } catch (E) { console.log(E) }

  }

  async slashExecute(client, interaction) {
    try {
      const inviteBtn = new ButtonBuilder().setLabel('Invite').setStyle(ButtonStyle.Link).setURL('https://discord.com/oauth2/authorize?client_id=1531673443131588729')
      const supportBtn = new ButtonBuilder().setLabel('Support').setStyle(ButtonStyle.Link).setURL('https://discord.gg/sWsZy7VSM4')

      const selectOptions = [];
      const categories = (await fs.readdir('./commands')).filter(
        (c) => c.toLowerCase() !== 'ahiddenlist' && !c.startsWith('.')
      );
      for (const cate of categories) {
        selectOptions.push(
          {
            label: cate,
            value: cate.toLowerCase()
          }
        )
      }

      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('help_select')
        .setPlaceholder('Browse Categories')
        .addOptions(selectOptions);

      const row1 = new ActionRowBuilder().addComponents(selectMenu)
      const row2 = new ActionRowBuilder().addComponents(inviteBtn, supportBtn)

      const publicCommands = client.commands.filter(c => c.category?.toLowerCase() !== 'ahiddenlist');
      const container = new ContainerBuilder().setAccentColor(client.theme)
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${client.user.displayName}`))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
        .addSectionComponents(new SectionBuilder().setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: client.user.displayAvatarURL({ size: 1024, dynamic: true }) } })).addTextDisplayComponents(new TextDisplayBuilder().setContent
          (`Commands: \`${publicCommands.size}\`\nSlash Commands: \`${client.slashCommands.length}\`\nPrefix: \`${client.defaultPrefix}\`\nWebsocket Latency: \`${client.ws.ping}ms\``)))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# Use below select menu to browse`))
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
        .addActionRowComponents(row1)
        .addActionRowComponents(row2)
        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# for @${interaction.user.tag}`));
      const sent = await interaction.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      const collector = sent.createMessageComponentCollector({
        componentType: ComponentType.StringSelect,
        time: 60000
      });

      collector.on('collect', async (i) => {
        try {
          if (i.user.id !== interaction.user.id) {
            return i.reply({ content: `This menu is not for you.`, flags: MessageFlags.Ephemeral });
          }
          await i.deferReply({ flags: MessageFlags.Ephemeral });

          const selection = i.values[0];
          const targetCat = categories.find(c => c.toLowerCase() === selection);
          if (targetCat) {
            const categoryCmds = client.commands.filter(c => c.category?.toLowerCase() === targetCat.toLowerCase() && c.name !== 'help');

            let cmdListText = [];
            for (const [name, cmd] of categoryCmds) {
              const slashC = interaction.guild?.commands?.cache?.find(c => c.name === cmd.name) || client.application?.commands?.cache?.find(c => c.name === cmd.name);
              if (slashC) {
                cmdListText.push(`</${slashC.name}:${slashC.id}> • ${slashC.description || cmd.description}`);
              } else {
                cmdListText.push(`\`${cmd.name}\` • ${cmd.description || "No description"}`);
              }
            }

            let CatContainer = new ContainerBuilder().setAccentColor(client.theme)
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${targetCat}`))
              .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(cmdListText.join('\n') || "No commands found."))
              .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
              .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# Total commands: ${cmdListText.length}`));
            await i.editReply({ components: [CatContainer], flags: MessageFlags.IsComponentsV2 });
          }
        } catch (err) {
          console.error("Help menu slash collect error:", err);
        }
      });

      collector.on('end', async () => {
        const publicCmds = client.commands.filter(c => c.category?.toLowerCase() !== 'ahiddenlist');
        const endContainer = new ContainerBuilder().setAccentColor(client.theme)
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# ${client.user.displayName}`))
          .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
          .addSectionComponents(new SectionBuilder().setThumbnailAccessory(new ThumbnailBuilder({ description: 'avatar', media: { url: client.user.displayAvatarURL({ size: 1024, dynamic: true }) } })).addTextDisplayComponents(new TextDisplayBuilder().setContent
            (`Commands: \`${publicCmds.size}\`\nSlash Commands: \`${client.slashCommands.length}\`\nPrefix: \`${client.defaultPrefix}\`\nWebsocket Latency: \`${client.ws.ping}ms\``)))
          .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# Use below select menu to browse`))
          .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
          .addActionRowComponents(new ActionRowBuilder().addComponents(selectMenu.setDisabled(true)))
          .addActionRowComponents(row2)
          .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
          .addTextDisplayComponents(new TextDisplayBuilder().setContent(`-# for @${interaction.user.tag}`));
        await sent.edit({ components: [endContainer], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] } });
      });
    } catch (E) { console.log(E) }

  }
}