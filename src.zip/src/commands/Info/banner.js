import Command from "../../structure/Command.js";
import {MessageFlags, ContainerBuilder, TextDisplayBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, SlashCommandBuilder} from "discord.js";

async function MakeContainer(client, user) {
  const bannerURL = user.bannerURL({ size: 1024 });
  if (!bannerURL) return null;

  const dl = new ButtonBuilder().setLabel('Download').setURL(bannerURL).setStyle(ButtonStyle.Link)
  const container = new ContainerBuilder().setAccentColor(client.theme)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <@${user.id}>'s banner`))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addMediaGalleryComponents(new MediaGalleryBuilder({items: [{description: 'banner', media: {url: bannerURL}}]}))
    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
    .addActionRowComponents(new ActionRowBuilder().addComponents(dl))

  return container;
}

export default class BannerCommand extends Command {
  constructor() {
    super({
      name: 'banner',
      aliases: ['bn'],
      description: 'Shows a user\'s banner',
      slash: true,
      data: new SlashCommandBuilder()
        .setName('banner')
        .setDescription('Shows a user\'s banner')
        .addUserOption(option =>
          option
            .setName('user')
            .setDescription('The member to get the banner of')
            .setRequired(false)
        )
    });
  }

  async execute(client, message, args) {
    let member = message.mentions.members.first();
    if (!member && args[0]) {
        member = message.guild.members.cache.get(args[0]);
    }
    if (!member) member = message.member;

    const user = await member.user.fetch({ force: true });
    const container = await MakeContainer(client, user);
    if (!container) return message.reply({ content: 'That user has no banner.', allowedMentions: { parse: [] } });
    await message.reply({components:[container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] }});
  }

  async slashExecute(client, interaction) {
    const member = interaction.options.getMember('user') ?? interaction.member;
    const user = await member.user.fetch({ force: true });

    const container = await MakeContainer(client, user);
    if (!container) return interaction.reply({ content: 'That user has no banner.', allowedMentions: { parse: [] } });
    await interaction.reply({components:[container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] }});
  }
}
