import Command from "../../structure/Command.js";
import {MessageFlags, ContainerBuilder, TextDisplayBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder, SeparatorBuilder, SeparatorSpacingSize, MediaGalleryBuilder, SlashCommandBuilder} from "discord.js";

async function MakeContainer(client, user) {
  const dl = new ButtonBuilder().setLabel('Download').setURL(user.displayAvatarURL({ size: 1024, dynamic: true })).setStyle(ButtonStyle.Link)
  const container = new ContainerBuilder().setAccentColor(client.theme)
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`# <@${user.id}>'s avatar`))
  .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
  .addMediaGalleryComponents(new MediaGalleryBuilder({items: [{description: 'avatar', media: {url: user.displayAvatarURL({ size: 1024, dynamic: true })}}]}))
  .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
  .addActionRowComponents(new ActionRowBuilder().addComponents(dl))

  return container;
}

export default class AvatarCommand extends Command {
  constructor() {
    super({
      name: 'avatar',
      aliases: ['av'],
      description: 'The member to get the avatar of',
      slash: true,
      data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Shows a user\'s avatar')
        .addUserOption(option =>
          option
            .setName('user')
            .setDescription('The member to get the avatar of')
            .setRequired(false)
        )
    });
  }

  async execute(client, message, args) {
    let member = message.mentions.members.first();
    if (!member && args[0]) {
        member = message.guild.members.cache.get(args[0]);
    }
    if (!member) member = message.member;
    
    const container = await MakeContainer(client, member)
    await message.reply({components:[container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] }});
  }

  async slashExecute(client, interaction) {
    const member = interaction.options.getMember('user') ?? interaction.member;
    const user = member.user;

    const container = await MakeContainer(client, user)
    await interaction.reply({components:[container], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: [] }});
  }
}