import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class TwentyFourSevenCommand extends Command {
  constructor() {
    super({
      name: "247",
      aliases: ["twentyfourseven", "stay"],
      description: "Toggle 24/7 mode to keep the bot in voice channel indefinitely",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("247")
        .setDescription("Toggle 24/7 mode to keep the bot in voice channel indefinitely")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      let player = client.riffy.players.get(message.guild.id);
      if (!player) {
        player = client.riffy.createConnection({
          guildId: message.guild.id,
          voiceChannel: voiceCheck.channel.id,
          textChannel: message.channel.id,
          deaf: true
        });
      }

      player.twentyFourSeven = !player.twentyFourSeven;

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} 24/7 mode is now **\`${player.twentyFourSeven ? "enabled" : "disabled"}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      let player = client.riffy.players.get(interaction.guild.id);
      if (!player) {
        player = client.riffy.createConnection({
          guildId: interaction.guild.id,
          voiceChannel: voiceCheck.channel.id,
          textChannel: interaction.channel.id,
          deaf: true
        });
      }

      player.twentyFourSeven = !player.twentyFourSeven;

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} 24/7 mode is now **\`${player.twentyFourSeven ? "enabled" : "disabled"}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
