import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder,
  PermissionFlagsBits
} from "discord.js";
import { Tick, Cross } from "../../utils/emojis.js";
import db from "../../utils/database.js";

export default class PrefixCommand extends Command {
  constructor() {
    super({
      name: "prefix",
      aliases: ["setprefix"],
      description: "View or set the server prefix",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("prefix")
        .setDescription("View or set the server prefix")
        .addStringOption((opt) =>
          opt
            .setName("new_prefix")
            .setDescription("The new prefix for this server (leave empty to view)")
            .setRequired(false)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const currentPrefix = db.getPrefix(message.guild.id) || client.defaultPrefix;
      const newPrefix = args[0]?.trim();

      if (!newPrefix) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `The current prefix for this server is **\`${currentPrefix}\`**.`
            )
          );
        return message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} You need the \`Manage Server\` permission to change the prefix.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      if (newPrefix.length > 5) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} Prefix cannot be longer than 5 characters.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      db.setPrefix(message.guild.id, newPrefix);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Server prefix has been updated to **\`${newPrefix}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const currentPrefix = db.getPrefix(interaction.guild.id) || client.defaultPrefix;
      const newPrefix = interaction.options.getString("new_prefix")?.trim();

      if (!newPrefix) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `The current prefix for this server is **\`${currentPrefix}\`**.`
            )
          );
        return interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      if (!interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} You need the \`Manage Server\` permission to change the prefix.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      if (newPrefix.length > 5) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} Prefix cannot be longer than 5 characters.`)
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      db.setPrefix(interaction.guild.id, newPrefix);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Server prefix has been updated to **\`${newPrefix}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
