import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Cross } from "../../utils/emojis.js";
import { checkVoice, formatTime, makeSkipToButtonRow } from "../../utils/musicHelper.js";

function validateInput(rawQuery) {
  const query = rawQuery.trim();
  const isUrl = /^https?:\/\//i.test(query);

  if (isUrl) {
    try {
      const parsed = new URL(query);
      const host = parsed.hostname.toLowerCase();
      const isAppleMusic =
        host === "music.apple.com" ||
        host.endsWith(".music.apple.com") ||
        host === "itunes.apple.com";

      if (!isAppleMusic) {
        return {
          valid: false,
          error: "URLs are not supported at the moment."
        };
      }
      return { valid: true, query, isUrl: true };
    } catch {
      return {
        valid: false,
        error: "URLs are not supported at the moment."
      };
    }
  }

  const cleanQuery = query.replace(/^[a-z0-9_-]+:\s*/i, "").trim();
  return { valid: true, query: cleanQuery, isUrl: false };
}

async function MakePlayContainer(client, track, isPlaylist = false, count = 1, disabled = false) {
  const title = track.info?.title || "Unknown Track";
  const uri = track.info?.uri || "https://music.apple.com";
  const artist = track.info?.author || "Unknown Artist";
  const duration = isPlaylist ? `${count} tracks` : formatTime(track.info?.length || 0);
  const requesterId = track.info?.requester?.id || track.requester?.id || client.user.id;
  const thumbnail = track.info?.thumbnail || track.info?.artworkUrl || client.user.displayAvatarURL({ size: 1024 });

  const content = [
    `### [${title}](${uri})`,
    `- Artist: ${artist}`,
    `- Duration: \`${duration}\``,
    `- Requested by: <@${requesterId}>`
  ].join("\n");

  const section = new SectionBuilder()
    .setThumbnailAccessory(new ThumbnailBuilder({ description: "cover", media: { url: thumbnail } }))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

  const container = new ContainerBuilder()
    .setAccentColor(client.theme)
    .addSectionComponents(section)
    .addActionRowComponents(makeSkipToButtonRow(track._skiptoId, disabled));

  return container;
}

export default class PlayCommand extends Command {
  constructor() {
    super({
      name: "play",
      aliases: ["p"],
      description: "Play an Apple Music track or search Apple Music",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("play")
        .setDescription("Play an Apple Music track or search Apple Music")
        .addStringOption((opt) =>
          opt
            .setName("query")
            .setDescription("The Apple Music song name or music.apple.com URL")
            .setRequired(true)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const rawQuery = args.join(" ");
      if (!rawQuery) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Please provide a song name or an Apple Music URL (\`music.apple.com\`).`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const check = validateInput(rawQuery);
      if (!check.valid) {
        const rejectContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} ${check.error}`)
          );
        return message.reply({
          components: [rejectContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      let player = client.riffy.players.get(message.guild.id);
      if (!player) {
        player = client.riffy.createConnection({
          guildId: message.guild.id,
          voiceChannel: voiceCheck.channel.id,
          textChannel: message.channel.id,
          deaf: true
        });
      }

      const resolveOptions = check.isUrl
        ? { query: check.query, requester: message.author }
        : { query: check.query, source: "amsearch", requester: message.author };

      const resolve = await client.riffy.resolve(resolveOptions);
      if (!resolve || !resolve.tracks || resolve.tracks.length === 0) {
        const noResContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} No results found on Apple Music for \`${check.query}\`.`
            )
          );
        return message.reply({
          components: [noResContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const isPlaylist = resolve.loadType === "playlist" || resolve.loadType === "PLAYLIST_LOADED";
      if (isPlaylist) {
        const skiptoId = `st_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        for (let i = 0; i < resolve.tracks.length; i++) {
          const t = resolve.tracks[i];
          t.info.requester = message.author;
          if (i === 0) t._skiptoId = skiptoId;
          player.queue.add(t);
        }
        if (!player.playing && !player.paused) await player.play();

        const firstTrack = resolve.tracks[0];
        firstTrack._skiptoId = skiptoId;
        const container = await MakePlayContainer(
          client,
          firstTrack,
          true,
          resolve.tracks.length,
          false
        );
        const sent = await message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });

        const collector = sent.createMessageComponentCollector({ time: 30000 });
        collector.on("end", async () => {
          try {
            const expired = await MakePlayContainer(
              client,
              firstTrack,
              true,
              resolve.tracks.length,
              true
            );
            await sent.edit({
              components: [expired],
              flags: MessageFlags.IsComponentsV2,
              allowedMentions: { parse: [] }
            });
          } catch { }
        });
        return;
      }

      const track = resolve.tracks[0];
      const skiptoId = `st_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      track._skiptoId = skiptoId;
      track.info.requester = message.author;
      const isPlayingNow = !player.playing && !player.paused && player.queue.size === 0;

      if (isPlayingNow) {
        player.queue.add(track);
        await player.play();
      } else {
        player.queue.add(track);
      }

      const container = await MakePlayContainer(client, track, false, 1, false);
      const sent = await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });

      const collector = sent.createMessageComponentCollector({ time: 30000 });
      collector.on("end", async () => {
        try {
          const expired = await MakePlayContainer(client, track, false, 1, true);
          await sent.edit({
            components: [expired],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] }
          });
        } catch { }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const rawQuery = interaction.options.getString("query");
      const check = validateInput(rawQuery);

      if (!check.valid) {
        const rejectContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} ${check.error}`)
          );
        return interaction.reply({
          components: [rejectContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      let player = client.riffy.players.get(interaction.guild.id);
      if (!player) {
        player = client.riffy.createConnection({
          guildId: interaction.guild.id,
          voiceChannel: voiceCheck.channel.id,
          textChannel: interaction.channel.id,
          deaf: true
        });
      }

      const resolveOptions = check.isUrl
        ? { query: check.query, requester: interaction.user }
        : { query: check.query, source: "amsearch", requester: interaction.user };

      const resolve = await client.riffy.resolve(resolveOptions);
      if (!resolve || !resolve.tracks || resolve.tracks.length === 0) {
        const noResContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} No results found on Apple Music for \`${check.query}\`.`
            )
          );
        return interaction.reply({
          components: [noResContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const isPlaylist = resolve.loadType === "playlist" || resolve.loadType === "PLAYLIST_LOADED";
      if (isPlaylist) {
        const skiptoId = `st_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
        for (let i = 0; i < resolve.tracks.length; i++) {
          const t = resolve.tracks[i];
          t.info.requester = interaction.user;
          if (i === 0) t._skiptoId = skiptoId;
          player.queue.add(t);
        }
        if (!player.playing && !player.paused) await player.play();

        const firstTrack = resolve.tracks[0];
        firstTrack._skiptoId = skiptoId;
        const container = await MakePlayContainer(
          client,
          firstTrack,
          true,
          resolve.tracks.length,
          false
        );
        await interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });

        try {
          const replyMsg = await interaction.fetchReply();
          const collector = replyMsg.createMessageComponentCollector({ time: 30000 });
          collector.on("end", async () => {
            try {
              const expired = await MakePlayContainer(
                client,
                firstTrack,
                true,
                resolve.tracks.length,
                true
              );
              await interaction.editReply({
                components: [expired],
                flags: MessageFlags.IsComponentsV2,
                allowedMentions: { parse: [] }
              });
            } catch { }
          });
        } catch { }
        return;
      }

      const track = resolve.tracks[0];
      const skiptoId = `st_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      track._skiptoId = skiptoId;
      track.info.requester = interaction.user;
      const isPlayingNow = !player.playing && !player.paused && player.queue.size === 0;

      if (isPlayingNow) {
        player.queue.add(track);
        await player.play();
      } else {
        player.queue.add(track);
      }

      const container = await MakePlayContainer(client, track, false, 1, false);
      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });

      try {
        const replyMsg = await interaction.fetchReply();
        const collector = replyMsg.createMessageComponentCollector({ time: 30000 });
        collector.on("end", async () => {
          try {
            const expired = await MakePlayContainer(client, track, false, 1, true);
            await interaction.editReply({
              components: [expired],
              flags: MessageFlags.IsComponentsV2,
              allowedMentions: { parse: [] }
            });
          } catch { }
        });
      } catch { }
    } catch (e) {
      console.log(e);
    }
  }
}
