import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick, Cross } from "../../utils/emojis.js";

export default class ConnectCommand extends Command {
  constructor() {
    super({
      name: "connect",
      aliases: ["join", "summon"],
      description: "Connect the bot to your voice channel",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("connect")
        .setDescription("Connect the bot to your voice channel")
    });
  }

  async execute(client, message, args) {
    try {
      const channel = message.member.voice?.channel;
      if (!channel) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} You must be connected to a voice channel.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      client.riffy.createConnection({
        guildId: message.guild.id,
        voiceChannel: channel.id,
        textChannel: message.channel.id,
        deaf: true
      });

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} Successfully joined <#${channel.id}>.`)
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const channel = interaction.member.voice?.channel;
      if (!channel) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} You must be connected to a voice channel.`)
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      client.riffy.createConnection({
        guildId: interaction.guild.id,
        voiceChannel: channel.id,
        textChannel: interaction.channel.id,
        deaf: true
      });

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} Successfully joined <#${channel.id}>.`)
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
