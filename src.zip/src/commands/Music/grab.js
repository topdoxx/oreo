import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick, Cross, Warn, Play } from "../../utils/emojis.js";
import { formatTime } from "../../utils/musicHelper.js";

async function MakeGrabDmContainer(client, track, guild) {
  const title = track.info?.title || "Unknown Track";
  const author = track.info?.author || "Unknown Artist";
  const uri = track.info?.uri || "https://music.apple.com";
  const duration = formatTime(track.info?.length || 0);

  const container = new ContainerBuilder()
    .setAccentColor(client.theme)
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `${Play} [${title}](${uri}) • \`${duration}\` • ${author} (from ${guild.name})`
      )
    );

  if (uri && /^https?:\/\//i.test(uri)) {
    const btn = new ButtonBuilder().setLabel("Listen on Apple Music").setStyle(ButtonStyle.Link).setURL(uri);
    container.addActionRowComponents(new ActionRowBuilder().addComponents(btn));
  }

  return container;
}

export default class GrabCommand extends Command {
  constructor() {
    super({
      name: "grab",
      aliases: ["save", "dm"],
      description: "Sends the currently playing track to your Direct Messages",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("grab")
        .setDescription("Sends the currently playing track to your Direct Messages")
    });
  }

  async execute(client, message, args) {
    try {
      const player = client.riffy?.players.get(message.guild.id);
      if (!player || !player.current) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no song currently playing.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const track = player.current;
      const dmContainer = await MakeGrabDmContainer(client, track, message.guild);

      try {
        await message.author.send({
          components: [dmContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });

        const replyContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Tick} Sent [${track.info.title}](${track.info.uri}) to your DMs!`
            )
          );

        await message.reply({
          components: [replyContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      } catch (err) {
        const failContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Could not send DM. Please make sure your DMs are open.`
            )
          );
        await message.reply({
          components: [failContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const player = client.riffy?.players.get(interaction.guild.id);
      if (!player || !player.current) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no song currently playing.`)
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const track = player.current;
      const dmContainer = await MakeGrabDmContainer(client, track, interaction.guild);

      try {
        await interaction.user.send({
          components: [dmContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });

        const replyContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Tick} Sent [${track.info.title}](${track.info.uri}) to your DMs!`
            )
          );

        await interaction.reply({
          components: [replyContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      } catch (err) {
        const failContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Could not send DM. Please make sure your DMs are open.`
            )
          );
        await interaction.reply({
          components: [failContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }
    } catch (e) {
      console.log(e);
    }
  }
}
