import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Skip, Cross } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class SkipToCommand extends Command {
  constructor() {
    super({
      name: "skipto",
      aliases: ["st"],
      description: "Skip to a specific track in the queue",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("skipto")
        .setDescription("Skip to a specific track in the queue")
        .addIntegerOption((opt) =>
          opt
            .setName("position")
            .setDescription("The position of the track in queue to skip to")
            .setRequired(true)
            .setMinValue(1)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const position = parseInt(args[0]);

      if (isNaN(position) || position < 1 || position > player.queue.length) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid position. Please enter a number between \`1\` and \`${player.queue.length}\`.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const targetTrack = player.queue[position - 1];
      player.queue.splice(0, position - 1);
      player.stop();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Skip} Skipped to [${targetTrack.info.title}](${targetTrack.info.uri}) at position \`#${position}\`.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const position = interaction.options.getInteger("position");

      if (position < 1 || position > player.queue.length) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid position. Please enter a number between \`1\` and \`${player.queue.length}\`.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const targetTrack = player.queue[position - 1];
      player.queue.splice(0, position - 1);
      player.stop();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Skip} Skipped to [${targetTrack.info.title}](${targetTrack.info.uri}) at position \`#${position}\`.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
