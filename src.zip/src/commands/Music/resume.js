import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Play, Warn } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class ResumeCommand extends Command {
  constructor() {
    super({
      name: "resume",
      aliases: ["unpause"],
      description: "Resume playback of the current song",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("resume")
        .setDescription("Resume playback of the current song")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      if (!player.paused) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} The player is already playing.`)
          );
        return message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      player.pause(false);
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Play} Resumed playback of [${player.current.info.title}](${player.current.info.uri}).`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      if (!player.paused) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} The player is already playing.`)
          );
        return interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      player.pause(false);
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Play} Resumed playback of [${player.current.info.title}](${player.current.info.uri}).`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
