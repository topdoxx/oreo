import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Play, Cross } from "../../utils/emojis.js";
import { checkVoice, parseTime, formatTime } from "../../utils/musicHelper.js";

export default class SeekCommand extends Command {
  constructor() {
    super({
      name: "seek",
      aliases: [],
      description: "Seek to a specific timestamp in the currently playing track",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("seek")
        .setDescription("Seek to a specific timestamp in the currently playing track")
        .addStringOption((opt) =>
          opt
            .setName("time")
            .setDescription("Timestamp to seek to (e.g. 1:30, 90s, 2m)")
            .setRequired(true)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const timeInput = args[0];
      const ms = parseTime(timeInput);
      const player = voiceCheck.player;

      if (ms === null || isNaN(ms)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid time format. Examples: \`1:30\`, \`90s\`, \`2m\`, \`180\`.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const totalMs = player.current.info.length || 0;
      if (totalMs > 0 && ms > totalMs) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Target time exceeds track duration of \`${formatTime(totalMs)}\`.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      player.seek(ms);
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Play} Seeked playback to **\`${formatTime(ms)}\`** / \`${formatTime(totalMs)}\`.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const timeInput = interaction.options.getString("time");
      const ms = parseTime(timeInput);
      const player = voiceCheck.player;

      if (ms === null || isNaN(ms)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid time format. Examples: \`1:30\`, \`90s\`, \`2m\`, \`180\`.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const totalMs = player.current.info.length || 0;
      if (totalMs > 0 && ms > totalMs) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Target time exceeds track duration of \`${formatTime(totalMs)}\`.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      player.seek(ms);
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Play} Seeked playback to **\`${formatTime(ms)}\`** / \`${formatTime(totalMs)}\`.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
