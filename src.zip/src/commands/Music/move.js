import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick, Cross } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class MoveCommand extends Command {
  constructor() {
    super({
      name: "move",
      aliases: ["mv"],
      description: "Move a track from one position to another in the queue",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("move")
        .setDescription("Move a track from one position to another in the queue")
        .addIntegerOption((opt) =>
          opt
            .setName("from")
            .setDescription("The current position of the track")
            .setRequired(true)
            .setMinValue(1)
        )
        .addIntegerOption((opt) =>
          opt
            .setName("to")
            .setDescription("The new position of the track")
            .setRequired(true)
            .setMinValue(1)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const from = parseInt(args[0]);
      const to = parseInt(args[1]);

      if (
        isNaN(from) ||
        isNaN(to) ||
        from < 1 ||
        from > player.queue.length ||
        to < 1 ||
        to > player.queue.length ||
        from === to
      ) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid positions. Enter two different numbers between \`1\` and \`${player.queue.length}\`.`
            )
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const [item] = player.queue.splice(from - 1, 1);
      player.queue.splice(to - 1, 0, item);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Moved [${item.info.title}](${item.info.uri}) from position \`#${from}\` to \`#${to}\`.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const from = interaction.options.getInteger("from");
      const to = interaction.options.getInteger("to");

      if (
        from < 1 ||
        from > player.queue.length ||
        to < 1 ||
        to > player.queue.length ||
        from === to
      ) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `${Cross} Invalid positions. Enter two different numbers between \`1\` and \`${player.queue.length}\`.`
            )
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const [item] = player.queue.splice(from - 1, 1);
      player.queue.splice(to - 1, 0, item);

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Tick} Moved [${item.info.title}](${item.info.uri}) from position \`#${from}\` to \`#${to}\`.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
