import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Stop } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class StopCommand extends Command {
  constructor() {
    super({
      name: "stop",
      aliases: ["leave", "dc", "disconnect"],
      description: "Stop playback and clear the queue",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("stop")
        .setDescription("Stop playback and clear the queue")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = client.riffy?.players.get(message.guild.id);
      if (player) {
        player.destroy();
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Stop} Playback stopped and queue cleared.`)
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = client.riffy?.players.get(interaction.guild.id);
      if (player) {
        player.destroy();
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Stop} Playback stopped and queue cleared.`)
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
