import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SlashCommandBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize
} from "discord.js";
import { Warn } from "../../utils/emojis.js";
import { formatTime, createProgressBar, getActiveFilters, makePlayerControlsRow } from "../../utils/musicHelper.js";

async function MakeNowPlayingContainer(client, player, disabled = false) {
  const track = player.current;
  const currentMs = player.position || 0;
  const totalMs = track.info?.length || 0;
  const title = track.info?.title || "Unknown Track";
  const uri = track.info?.uri || "https://music.apple.com";
  const artist = track.info?.author || "Unknown Artist";
  const requesterId = track.info?.requester?.id || track.requester?.id || client.user.id;

  let thumbnail = track.info?.thumbnail || track.info?.artworkUrl;
  if (!thumbnail || typeof thumbnail !== "string" || !thumbnail.startsWith("http")) {
    thumbnail = client.user.displayAvatarURL({ size: 1024 });
  }

  const durationText = totalMs > 0 ? `\`${formatTime(currentMs)} / ${formatTime(totalMs)}\`` : "`Live`";
  const progressBar = createProgressBar(currentMs, totalMs, 12);

  const loopMode = player.loop === "track" ? "Track" : player.loop === "queue" ? "Queue" : "Off";
  const volume = player.volume ?? 100;
  const queueLength = player.queue.length;
  const activeFilters = getActiveFilters(player);

  const content = [
    `### [${title}](${uri})`,
    `- Artist: **${artist}**`,
    `- Duration: **${durationText}**`,
    `- Requested by: **<@${requesterId}>**`
  ].join("\n");

  const section = new SectionBuilder()
    .setThumbnailAccessory(new ThumbnailBuilder({ description: "cover", media: { url: thumbnail } }))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(content));

  const extraInfo = [
    `-# Loop: ${loopMode} • Volume: ${volume}% • Queue: ${queueLength} • Filter: ${activeFilters}`
  ].join("\n");

  const container = new ContainerBuilder()
    .setAccentColor(client.theme)
    .addSectionComponents(section)
    .addActionRowComponents(makePlayerControlsRow(disabled));

  return container;
}

export default class NowPlayingCommand extends Command {
  constructor() {
    super({
      name: "nowplaying",
      aliases: ["np", "current"],
      description: "Shows information about the currently playing song",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("nowplaying")
        .setDescription("Shows information about the currently playing song")
    });
  }

  async execute(client, message, args) {
    try {
      const player = client.riffy?.players.get(message.guild.id);
      if (!player || !player.current) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no song currently playing.`)
          );
        return message.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const container = await MakeNowPlayingContainer(client, player, false);
      const sent = await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });

      const collector = sent.createMessageComponentCollector({ time: 30000 });
      collector.on("end", async () => {
        try {
          const expired = await MakeNowPlayingContainer(client, player, true);
          await sent.edit({
            components: [expired],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] }
          });
        } catch { }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const player = client.riffy?.players.get(interaction.guild.id);
      if (!player || !player.current) {
        const container = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is no song currently playing.`)
          );
        return interaction.reply({
          components: [container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const container = await MakeNowPlayingContainer(client, player, false);
      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });

      try {
        const replyMsg = await interaction.fetchReply();
        const collector = replyMsg.createMessageComponentCollector({ time: 30000 });
        collector.on("end", async () => {
          try {
            const expired = await MakeNowPlayingContainer(client, player, true);
            await interaction.editReply({
              components: [expired],
              flags: MessageFlags.IsComponentsV2,
              allowedMentions: { parse: [] }
            });
          } catch { }
        });
      } catch { }
    } catch (e) {
      console.log(e);
    }
  }
}
