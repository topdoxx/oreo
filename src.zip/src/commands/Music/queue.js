import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize
} from "discord.js";
import { Warn, Music } from "../../utils/emojis.js";
import { formatTime } from "../../utils/musicHelper.js";
import { paginator } from "../../utils/Paginator.js";

export default class QueueCommand extends Command {
  constructor() {
    super({
      name: "queue",
      aliases: ["q"],
      description: "Display the current music queue with pagination",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("queue")
        .setDescription("Display the current music queue with pagination")
    });
  }

  generatePages(player) {
    const current = player.current;
    const queue = player.queue;
    const pageSize = 10;
    const totalTracks = queue.length + (current ? 1 : 0);
    const totalDurationMs =
      (current?.info?.length || 0) +
      queue.reduce((acc, t) => acc + (t.info?.length || 0), 0);

    const pages = [];
    const totalPages = Math.max(1, Math.ceil(queue.length / pageSize));

    for (let p = 0; p < totalPages; p++) {
      const start = p * pageSize;
      const tracksOnPage = queue.slice(start, start + pageSize);

      let text = `## Queue \n\n`;

      if (current && p === 0) {
        text += `Now: [${current.info.title}](${current.info.uri}) • \`${formatTime(current.info.length)}\`\n`;
      }

      if (tracksOnPage.length > 0) {
        const lines = tracksOnPage.map((t, i) => {
          const pos = start + i + 1;
          return `${pos}. [${t.info.title}](${t.info.uri}) • \`${formatTime(t.info.length)}\``;
        });
        text += lines.join("\n");
      } else if (!current) {
        text += "Queue is empty.";
      }

      text += `\n\n-# Showing page ${p + 1}/${totalPages}`;
      pages.push(text);
    }

    return pages;
  }

  async execute(client, message, args) {
    try {
      const player = client.riffy?.players.get(message.guild.id);
      if (!player || (!player.current && player.queue.length === 0)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is nothing in the queue.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const pages = this.generatePages(player);
      await paginator(message, pages);
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const player = client.riffy?.players.get(interaction.guild.id);
      if (!player || (!player.current && player.queue.length === 0)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Warn} There is nothing in the queue.`)
          );
        return interaction.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const pages = this.generatePages(player);
      await paginator(interaction, pages);
    } catch (e) {
      console.log(e);
    }
  }
}
