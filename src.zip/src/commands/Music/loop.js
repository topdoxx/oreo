import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Loop, Cross } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class LoopCommand extends Command {
  constructor() {
    super({
      name: "loop",
      aliases: ["repeat"],
      description: "Set or toggle repeat mode for current track or queue",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("loop")
        .setDescription("Set or toggle repeat mode for current track or queue")
        .addStringOption((opt) =>
          opt
            .setName("mode")
            .setDescription("The loop mode to set")
            .setRequired(false)
            .addChoices(
              { name: "Off", value: "none" },
              { name: "Track", value: "track" },
              { name: "Queue", value: "queue" }
            )
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      let inputMode = args[0]?.toLowerCase();
      if (inputMode === "off") inputMode = "none";

      if (inputMode) {
        if (!["none", "track", "queue"].includes(inputMode)) {
          const errContainer = new ContainerBuilder()
            .setAccentColor(client.theme)
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(
                `${Cross} Invalid mode. Options are: \`off\`, \`track\`, \`queue\`.`
              )
            );
          return message.reply({
            components: [errContainer],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { parse: [] }
          });
        }
        player.setLoop(inputMode);
      } else {
        const currentLoop = player.loop || "none";
        if (currentLoop === "none") player.setLoop("track");
        else if (currentLoop === "track") player.setLoop("queue");
        else player.setLoop("none");
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Loop} Loop mode is now set to **\`${player.loop === "none" ? "off" : player.loop}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const mode = interaction.options.getString("mode");

      if (mode) {
        player.setLoop(mode);
      } else {
        const currentLoop = player.loop || "none";
        if (currentLoop === "none") player.setLoop("track");
        else if (currentLoop === "track") player.setLoop("queue");
        else player.setLoop("none");
      }

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${Loop} Loop mode is now set to **\`${player.loop === "none" ? "off" : player.loop}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
