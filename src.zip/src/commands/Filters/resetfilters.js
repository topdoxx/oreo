import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Tick } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class ResetFiltersCommand extends Command {
  constructor() {
    super({
      name: "resetfilters",
      aliases: ["clearfilters", "rf"],
      description: "Reset and clear all active audio filters",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("resetfilters")
        .setDescription("Reset and clear all active audio filters")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      await player.filters.clearFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} All audio filters have been reset.`)
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      await player.filters.clearFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Tick} All audio filters have been reset.`)
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
