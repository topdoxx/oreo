import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { Cross, filter } from "../../utils/emojis.js";
import { checkVoice } from "../../utils/musicHelper.js";

export default class BassboostCommand extends Command {
  constructor() {
    super({
      name: "bassboost",
      aliases: ["bb", "bass"],
      description: "Toggle or set bassboost audio filter",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("bassboost")
        .setDescription("Toggle or set bassboost audio filter")
        .addIntegerOption((opt) =>
          opt
            .setName("level")
            .setDescription("Bassboost level (0 to 5, 0 = off)")
            .setRequired(false)
            .setMinValue(0)
            .setMaxValue(5)
        )
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      let level = args[0] ? parseInt(args[0]) : null;

      if (level !== null && (isNaN(level) || level < 0 || level > 5)) {
        const errContainer = new ContainerBuilder()
          .setAccentColor(client.theme)
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${Cross} Bassboost level must be between 0 and 5.`)
          );
        return message.reply({
          components: [errContainer],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      if (level === null) {
        level = player.filters.bassboost ? 0 : 5;
      }

      if (level === 0) {
        player.filters.setBassboost(false);
      } else {
        player.filters.setBassboost(true, { value: level });
      }
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Bassboost is now **\`${level === 0 ? "disabled" : `level ${level}`}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      let level = interaction.options.getInteger("level");

      if (level === null) {
        level = player.filters.bassboost ? 0 : 5;
      }

      if (level === 0) {
        player.filters.setBassboost(false);
      } else {
        player.filters.setBassboost(true, { value: level });
      }
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Bassboost is now **\`${level === 0 ? "disabled" : `level ${level}`}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
