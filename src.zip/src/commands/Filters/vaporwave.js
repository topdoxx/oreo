import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { checkVoice } from "../../utils/musicHelper.js";
import { filter } from "../../utils/emojis.js";

export default class VaporwaveCommand extends Command {
  constructor() {
    super({
      name: "vaporwave",
      aliases: ["vwave"],
      description: "Toggle vaporwave audio filter",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("vaporwave")
        .setDescription("Toggle vaporwave audio filter")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const isEnabled = !player.filters.vaporwave;
      player.filters.setVaporwave(isEnabled);
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Vaporwave filter is now **\`${isEnabled ? "enabled" : "disabled"}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const isEnabled = !player.filters.vaporwave;
      player.filters.setVaporwave(isEnabled);
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Vaporwave filter is now **\`${isEnabled ? "enabled" : "disabled"}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
