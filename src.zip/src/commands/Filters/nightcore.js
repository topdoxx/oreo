import Command from "../../structure/Command.js";
import {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SlashCommandBuilder
} from "discord.js";
import { checkVoice } from "../../utils/musicHelper.js";
import { filter } from "../../utils/emojis.js";

export default class NightcoreCommand extends Command {
  constructor() {
    super({
      name: "nightcore",
      aliases: ["nc"],
      description: "Toggle nightcore audio filter",
      slash: true,
      data: new SlashCommandBuilder()
        .setName("nightcore")
        .setDescription("Toggle nightcore audio filter")
    });
  }

  async execute(client, message, args) {
    try {
      const voiceCheck = checkVoice(client, message.member, true);
      if (!voiceCheck.ok) {
        return message.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const isEnabled = !player.filters.nightcore;
      player.filters.setNightcore(isEnabled);
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Nightcore filter is now **\`${isEnabled ? "enabled" : "disabled"}\`**.`
          )
        );

      await message.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }

  async slashExecute(client, interaction) {
    try {
      const voiceCheck = checkVoice(client, interaction.member, true);
      if (!voiceCheck.ok) {
        return interaction.reply({
          components: [voiceCheck.container],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      }

      const player = voiceCheck.player;
      const isEnabled = !player.filters.nightcore;
      player.filters.setNightcore(isEnabled);
      await player.filters.updateFilters();

      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            `${filter} Nightcore filter is now **\`${isEnabled ? "enabled" : "disabled"}\`**.`
          )
        );

      await interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (e) {
      console.log(e);
    }
  }
}
