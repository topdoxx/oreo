console.log('Starting script...')

import { Client, GatewayIntentBits, Collection, MessageFlags, Routes } from "discord.js";
import { Riffy } from "riffy";
import Loader from "./structure/Loader.js";
import { Cross, Warn, Play, Pause, Skip, Stop, Tick, PauseResume } from "./utils/emojis.js";
import db from "./utils/database.js";
import { logGuildJoin, logGuildLeave, logCommandExecution, logStatusEvent } from "./utils/webhookLogger.js";
import dotenv from "dotenv";
dotenv.config()

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
  ]
});

client.defaultPrefix = ',';
client.theme = 0xe3e3e3;
client.db = db;
client.developers = (process.env.DEVELOPER_IDS ? process.env.DEVELOPER_IDS.split(",") : ["1527605018335907840"]).map(id => id.trim());

client.commands = new Collection()
client.snipes = new Collection()
client.afks = new Collection()
client.slashCommands = []

const nodes = [
  {
    name: "Lavalink",
    host: process.env.LAVALINK_HOST || "0.0.0.0",
    port: parseInt(process.env.LAVALINK_PORT || "80"),
    password: process.env.LAVALINK_PASSWORD || "adihuvai",
    secure: false
  }
];

client.riffy = new Riffy(client, nodes, {
  send: (payload) => {
    const guild = client.guilds.cache.get(payload.d.guild_id);
    if (guild) guild.shard.send(payload);
  },
  defaultSearchPlatform: "amsearch",
  restVersion: "v4"
});

async function updateChannelVoiceStatus(client, channelId, status = null) {
  if (!channelId) return;
  try {
    const channel = client.channels.cache.get(channelId);
    if (channel && typeof channel.setStatus === "function") {
      await channel.setStatus(status || "");
      return;
    }
    await client.rest.put(Routes.channelVoiceStatus(channelId), {
      body: { status: status || "" }
    });
  } catch (err) {
    // Silently ignore if bot lacks Set Voice Channel Status permission or channel unavailable
  }
}

client.riffy.on("nodeConnect", (node) => {
  console.log(`[Riffy] Node ${node.name} connected.`);
});

client.riffy.on("nodeError", (node, error) => {
  console.error(`[Riffy] Node ${node.name} error: ${error.message}`);
});

client.riffy.on("trackStart", async (player, track) => {
  const channelId = player.voiceChannel || player.connection?.voiceChannel;
  const name = track?.info?.title || "Unknown Track";
  await updateChannelVoiceStatus(client, channelId, `Playing: **${name}**`.slice(0, 500));
});

client.riffy.on("trackEnd", async (player, track) => {
  const channelId = player.voiceChannel || player.connection?.voiceChannel;
  if (player.current && player.current !== track && player.playing) return;
  await updateChannelVoiceStatus(client, channelId, null);
});

client.riffy.on("queueEnd", async (player) => {
  const channelId = player.voiceChannel || player.connection?.voiceChannel;
  await updateChannelVoiceStatus(client, channelId, null);
  if (player.twentyFourSeven) return;
  player.destroy();
});

client.riffy.on("playerDestroy", async (player) => {
  const channelId = player.voiceChannel || player.connection?.voiceChannel;
  await updateChannelVoiceStatus(client, channelId, null);
});

client.on("raw", (d) => {
  client.riffy.updateVoiceState(d);
});

async function prefixCheck(msg) {
  let prefix = (msg.guild ? client.db.getPrefix(msg.guild.id) : null) || client.defaultPrefix;
  if (msg.content.startsWith(prefix)) {
    let ctx = msg.content.replace(prefix, '').trim().split(' ')
    return ctx;
  };
  if (msg.content.startsWith(`<@${client.user.id}>`)) {
    let ctx = msg.content.replace(`<@${client.user.id}>`, '').trim().split(' ')
    return ctx;
  };
  if (msg.author.id === '1527605018335907840') {
    let ctx = msg.content.trim().split(' ')
    return ctx;
  }
  return false;
}

async function syncSlashCommands() {
  const guilds = client.guilds.cache;
  let synced = 0;
  for (const [id, guild] of guilds) {
    try {
      await guild.commands.set(client.slashCommands);
      console.log(`Synced slash commands to guild: ${guild.name} (${id})`);
      synced++;
    } catch (err) {
      console.error(`Failed to sync slash commands to guild: ${guild.name} (${id})`, err);
    }
  }
  console.log(`Slash command sync complete: ${synced}/${guilds.size} guilds`);
}

client.on('clientReady', async () => {
  console.log(`Logged in: ${client.user.tag} | ${client.ws.ping}ms`)
  client.riffy.init(client.user.id)
  client.user.setStatus('idle')
  client.user.setActivity(',help', { type: 'LISTENING' });
  const loader = new Loader(client)
  await loader.loadCommands()
  await loader.loadEvents()
  await syncSlashCommands()
  await logStatusEvent("Online", `Logged in as **${client.user.tag}** (\`${client.user.id}\`)\nGuilds: **${client.guilds.cache.size}**\nPing: \`${client.ws.ping}ms\``);
});

client.on("shardResume", async (id) => {
  console.log(`Shard #${id} resumed.`);
  await logStatusEvent("Shard Resumed", `Shard \`#${id}\` successfully reconnected.`);
});

client.on("shardReconnecting", async (id) => {
  console.log(`Shard #${id} reconnecting...`);
  await logStatusEvent("Shard Reconnecting", `Shard \`#${id}\` is attempting to reconnect...`);
});

client.on("guildCreate", async (guild) => {
  if (client.db.isGuildBlacklisted(guild.id)) {
    console.log(`Guild ${guild.name} (${guild.id}) is blacklisted. Leaving...`);
    await guild.leave().catch(() => {});
    return;
  }
  await logGuildJoin(guild);
});

client.on("guildDelete", async (guild) => {
  await logGuildLeave(guild);
});

client.on('interactionCreate', async (interaction) => {
  if (client.db.isUserBlacklisted(interaction.user.id)) {
    return interaction.reply({
      content: `${Cross} You are blacklisted from using this bot.`,
      flags: MessageFlags.Ephemeral
    }).catch(() => {});
  }

  if (interaction.guildId && client.db.isGuildBlacklisted(interaction.guildId)) {
    if (interaction.guild) await interaction.guild.leave().catch(() => {});
    return interaction.reply({
      content: `${Cross} This server is blacklisted from using this bot.`,
      flags: MessageFlags.Ephemeral
    }).catch(() => {});
  }

  if (interaction.isButton()) {
    const { customId, guild, member, user } = interaction;
    if (customId && customId.startsWith('music_')) {
      if (!member?.voice?.channel) {
        return interaction.reply({
          content: `${Cross} You must be connected to a voice channel to use music controls.`,
          flags: MessageFlags.Ephemeral
        });
      }

      const botVoiceId = guild.members.me?.voice?.channelId;
      if (botVoiceId && botVoiceId !== member.voice.channel.id) {
        return interaction.reply({
          content: `${Cross} You must be in the same voice channel as me (<#${botVoiceId}>).`,
          flags: MessageFlags.Ephemeral
        });
      }

      const player = client.riffy.players.get(guild.id);
      if (!player) {
        return interaction.reply({
          content: `${Warn} No active music player found for this server.`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId === 'music_pause_resume') {
        if (player.paused) {
          player.pause(false);
          return interaction.reply({
            content: `${Play} Playback resumed.`,
            flags: MessageFlags.Ephemeral
          });
        } else {
          player.pause(true);
          return interaction.reply({
            content: `${Pause} Playback paused.`,
            flags: MessageFlags.Ephemeral
          });
        }
      }

      if (customId === 'music_skip') {
        if (!player.current) {
          return interaction.reply({
            content: `${Warn} There is no song currently playing to skip.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const title = player.current.info?.title || "current track";
        player.stop();
        return interaction.reply({
          content: `${Skip} Skipped **${title}**.`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId === 'music_like') {
        if (!player.current) {
          return interaction.reply({
            content: `${Warn} There is no song currently playing to like.`,
            flags: MessageFlags.Ephemeral
          });
        }
        const track = player.current;
        const uri = track.info?.uri || "";
        const alreadyLiked = client.db.isLiked(user.id, uri);
        if (alreadyLiked) {
          return interaction.reply({
            content: `${Warn} **${track.info.title}** is already in your liked songs!`,
            flags: MessageFlags.Ephemeral
          });
        }
        client.db.addLikedSong(user.id, track);
        return interaction.reply({
          content: `${Tick} Added **${track.info.title}** to your liked songs!`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId === 'music_stop') {
        player.destroy();
        return interaction.reply({
          content: `${Stop} Playback stopped and player disconnected.`,
          flags: MessageFlags.Ephemeral
        });
      }

      if (customId.startsWith('music_skipto')) {
        const skiptoId = customId.startsWith('music_skipto_')
          ? customId.replace('music_skipto_', '')
          : null;

        if (skiptoId && player.current && player.current._skiptoId === skiptoId) {
          return interaction.reply({
            content: `${Warn} **${player.current.info?.title || "This track"}** is already playing.`,
            flags: MessageFlags.Ephemeral
          });
        }

        if (skiptoId) {
          const targetIndex = player.queue.findIndex(t => t._skiptoId === skiptoId);
          if (targetIndex !== -1) {
            const targetTrack = player.queue[targetIndex];
            player.queue.splice(0, targetIndex);
            if (!player.playing && !player.paused) {
              await player.play();
            } else {
              player.stop();
            }
            return interaction.reply({
              content: `${Skip} Skipped to **${targetTrack.info.title}**.`,
              flags: MessageFlags.Ephemeral
            });
          }
          return interaction.reply({
            content: `${Warn} This track is no longer in the queue.`,
            flags: MessageFlags.Ephemeral
          });
        }

        if (player.queue.length > 0) {
          const targetTrack = player.queue[0];
          if (!player.playing && !player.paused) {
            await player.play();
          } else {
            player.stop();
          }
          return interaction.reply({
            content: `${Skip} Skipped to **${targetTrack.info.title}**.`,
            flags: MessageFlags.Ephemeral
          });
        }

        return interaction.reply({
          content: `${Warn} There are no tracks in the queue to skip to.`,
          flags: MessageFlags.Ephemeral
        });
      }
    }
    return;
  }

  if (!interaction.isChatInputCommand()) return;
  const cmd = client.commands.get(interaction.commandName);
  if (cmd) {
    try {
      logCommandExecution(cmd.name, interaction.user, interaction.guild, true);
      await cmd.slashExecute(client, interaction);
      console.log(`slash executed: ${cmd.name} | executor: ${interaction.user.tag} | guild: ${interaction.guild?.name || 'DM'}`);
    } catch (err) {
      console.log(`Error: ${err}`);
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp({ content: `${Cross} Unexpected error: \`${err}\``, allowedMentions: { parse: [] }, flags: MessageFlags.Ephemeral }).catch(() => { });
      } else {
        await interaction.reply({ content: `${Cross} Unexpected error: \`${err}\``, allowedMentions: { parse: [] }, flags: MessageFlags.Ephemeral }).catch(() => { });
      }
    }
  }
});

client.on('messageCreate', async (msg) => {
  if (msg.author.bot || !msg.guild) return;
  if (client.db.isUserBlacklisted(msg.author.id)) return;
  if (client.db.isGuildBlacklisted(msg.guild.id)) {
    await msg.guild.leave().catch(() => {});
    return;
  }

  const ctx = await prefixCheck(msg);
  if (!ctx) return;
  const cmdName = ctx.shift().toLowerCase();
  const args = ctx;
  let cmd = client.commands.get(cmdName) || client.commands.find((c) => c.aliases?.includes(cmdName));
  if (cmd) {
    try {
      logCommandExecution(cmd.name, msg.author, msg.guild, false);
      await cmd.execute(client, msg, args);
      console.log(`executed: ${cmd.name} | executor: ${msg.author.tag} | guild: ${msg.guild.name}`);
    } catch (err) {
      await msg.reply({ content: `${Cross} Unexpected error: \`${err}\``, allowedMentions: { parse: [] } });
      console.log(`Error: ${err}`);
    }
  }
});

client.login(process.env.TOKEN)