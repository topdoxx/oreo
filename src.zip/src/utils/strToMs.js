function strToMs(inputt) {
    const str = String(inputt);
    const match = str.match(/^(\d+)([smhd])$/i);
    if (!match) return false;

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();
    if (unit === 's') return value * 1000;
    if (unit === 'm') return value * 60 * 1000;
    if (unit === 'h') return value * 60 * 60 * 1000;
    if (unit === 'd') return value * 24 * 60 * 60 * 1000;
}

export { strToMs };