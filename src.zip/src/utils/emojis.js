const Tick = "<:wtick:1569210949452431522>";
const Cross = "<:wcross:1569210978812563567>";
const Warn = "<:wwarn:1569212158389125291>";
const PauseResume = "<:wpauseresume:1569210832930349106>";
const Play = PauseResume;
const Pause = PauseResume;
const Skip = "<:wnext:1569210917303091322>";
const Stop = "<:wstop:1569212118975381554>";
const Loop = "<:wrepeat:1569211088753659914>";
const Shuffle = "<:wshuffle:1569211009154154567>";
const Music = "<:wmusic:1569211067710574733>";
const Volume = "<:wspeaker:1569211037532561528>";
const filter = "<:wheadphones:1569212746623615076>";
const Filter = filter;
const swifi = "<:wwifi:1569232848613802044>";
const cleft = "<:wleft:1569232880167813200>";
const cright = "<:wright:1569232918272942080>";
const Heart = "<:wheart:1569210881223430255>";

export {
    Heart,
    Cross,
    Tick,
    Warn,
    PauseResume,
    Play,
    Pause,
    Skip,
    Stop,
    Loop,
    Shuffle,
    Music,
    Volume,
    filter,
    Filter,
    swifi,
    cleft,
    cright
};