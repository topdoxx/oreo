import Database from "better-sqlite3";
import path from "node:path";

class BotDatabase {
  constructor() {
    const dbPath = path.resolve("./database.sqlite");
    this.db = new Database(dbPath);
    this.init();
  }

  init() {
    // Guild prefixes table
    this.db.prepare(`
      CREATE TABLE IF NOT EXISTS guild_prefixes (
        guild_id TEXT PRIMARY KEY,
        prefix TEXT NOT NULL
      )
    `).run();

    // Liked songs table
    this.db.prepare(`
      CREATE TABLE IF NOT EXISTS liked_songs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        title TEXT NOT NULL,
        author TEXT,
        uri TEXT NOT NULL,
        length INTEGER DEFAULT 0,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, uri)
      )
    `).run();

    // Blacklisted users table
    this.db.prepare(`
      CREATE TABLE IF NOT EXISTS blacklisted_users (
        user_id TEXT PRIMARY KEY,
        reason TEXT,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();

    // Blacklisted guilds table
    this.db.prepare(`
      CREATE TABLE IF NOT EXISTS blacklisted_guilds (
        guild_id TEXT PRIMARY KEY,
        reason TEXT,
        added_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `).run();
  }

  // Prefix methods
  getPrefix(guildId) {
    if (!guildId) return null;
    const row = this.db.prepare("SELECT prefix FROM guild_prefixes WHERE guild_id = ?").get(guildId);
    return row ? row.prefix : null;
  }

  setPrefix(guildId, prefix) {
    if (!guildId || !prefix) return false;
    this.db.prepare(`
      INSERT INTO guild_prefixes (guild_id, prefix)
      VALUES (?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET prefix = excluded.prefix
    `).run(guildId, prefix.trim());
    return true;
  }

  // Liked songs methods
  addLikedSong(userId, track) {
    if (!userId || !track) return false;
    const title = track.info?.title || track.title || "Unknown Track";
    const author = track.info?.author || track.author || "Unknown Artist";
    const uri = track.info?.uri || track.uri || track.url;
    const length = track.info?.length || track.length || track.duration || 0;

    try {
      this.db.prepare(`
        INSERT INTO liked_songs (user_id, title, author, uri, length)
        VALUES (?, ?, ?, ?, ?)
        ON CONFLICT(user_id, uri) DO NOTHING
      `).run(userId, title, author, uri, length);
      return true;
    } catch (e) {
      console.error("Error adding liked song:", e);
      return false;
    }
  }

  removeLikedSong(userId, uriOrTitle) {
    if (!userId || !uriOrTitle) return false;
    const res = this.db.prepare(`
      DELETE FROM liked_songs
      WHERE user_id = ? AND (uri = ? OR title LIKE ? OR id = ?)
    `).run(userId, uriOrTitle, `%${uriOrTitle}%`, isNaN(uriOrTitle) ? -1 : parseInt(uriOrTitle));
    return res.changes > 0;
  }

  getLikedSongs(userId) {
    if (!userId) return [];
    return this.db.prepare(`
      SELECT id, title, author, uri, length, added_at
      FROM liked_songs
      WHERE user_id = ?
      ORDER BY id DESC
    `).all(userId);
  }

  isLiked(userId, uri) {
    if (!userId || !uri) return false;
    const row = this.db.prepare("SELECT id FROM liked_songs WHERE user_id = ? AND uri = ?").get(userId, uri);
    return !!row;
  }

  // Blacklist methods
  isUserBlacklisted(userId) {
    if (!userId) return false;
    const row = this.db.prepare("SELECT user_id FROM blacklisted_users WHERE user_id = ?").get(userId);
    return !!row;
  }

  blacklistUser(userId, reason = "No reason provided") {
    if (!userId) return false;
    this.db.prepare(`
      INSERT INTO blacklisted_users (user_id, reason)
      VALUES (?, ?)
      ON CONFLICT(user_id) DO UPDATE SET reason = excluded.reason
    `).run(userId, reason);
    return true;
  }

  unblacklistUser(userId) {
    if (!userId) return false;
    const info = this.db.prepare("DELETE FROM blacklisted_users WHERE user_id = ?").run(userId);
    return info.changes > 0;
  }

  getBlacklistedUsers() {
    return this.db.prepare("SELECT * FROM blacklisted_users ORDER BY added_at DESC").all();
  }

  isGuildBlacklisted(guildId) {
    if (!guildId) return false;
    const row = this.db.prepare("SELECT guild_id FROM blacklisted_guilds WHERE guild_id = ?").get(guildId);
    return !!row;
  }

  blacklistGuild(guildId, reason = "No reason provided") {
    if (!guildId) return false;
    this.db.prepare(`
      INSERT INTO blacklisted_guilds (guild_id, reason)
      VALUES (?, ?)
      ON CONFLICT(guild_id) DO UPDATE SET reason = excluded.reason
    `).run(guildId, reason);
    return true;
  }

  unblacklistGuild(guildId) {
    if (!guildId) return false;
    const info = this.db.prepare("DELETE FROM blacklisted_guilds WHERE guild_id = ?").run(guildId);
    return info.changes > 0;
  }

  getBlacklistedGuilds() {
    return this.db.prepare("SELECT * FROM blacklisted_guilds ORDER BY added_at DESC").all();
  }
}

export const db = new BotDatabase();
export default db;

