import {
  ContainerBuilder,
  TextDisplayBuilder,
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder
} from "discord.js";
import { Cross, Warn, PauseResume, Skip, Stop, Heart } from "./emojis.js";

export function formatTime(ms) {
  if (!ms || isNaN(ms) || ms < 0) return "00:00";
  const totalSeconds = Math.floor(ms / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }
  return `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
}

export function createProgressBar(currentMs, totalMs, size = 12) {
  if (!totalMs || totalMs <= 0) return "🔘" + "▬".repeat(size - 1);
  const progress = Math.min(1, Math.max(0, currentMs / totalMs));
  const progressIndex = Math.min(size - 1, Math.floor(progress * size));
  const before = "▬".repeat(progressIndex);
  const after = "▬".repeat(size - 1 - progressIndex);
  return `${before}🔘${after}`;
}

export function getActiveFilters(player) {
  if (!player?.filters) return "None";
  const active = [];
  if (player.filters._8d) active.push("8D");
  if (player.filters.bassboost) active.push("Bassboost");
  if (player.filters.distortion) active.push("Distortion");
  if (player.filters.karaoke) active.push("Karaoke");
  if (player.filters.lowPass) active.push("Lowpass");
  if (player.filters.nightcore) active.push("Nightcore");
  if (player.filters.slowmode) active.push("Slowmode");
  if (player.filters.tremolo) active.push("Tremolo");
  if (player.filters.vaporwave) active.push("Vaporwave");
  if (player.filters.vibrato) active.push("Vibrato");
  return active.length > 0 ? active.join(", ") : "None";
}

export function parseTime(str) {
  if (!str) return null;
  const s = String(str).trim();
  if (/^\d+$/.test(s)) return parseInt(s) * 1000;
  const mmss = s.match(/^(\d+):(\d+)$/);
  if (mmss) {
    return (parseInt(mmss[1]) * 60 + parseInt(mmss[2])) * 1000;
  }
  const hhmmss = s.match(/^(\d+):(\d+):(\d+)$/);
  if (hhmmss) {
    return (parseInt(hhmmss[1]) * 3600 + parseInt(hhmmss[2]) * 60 + parseInt(hhmmss[3])) * 1000;
  }
  const unitMatch = s.match(/^(\d+)([smh])$/i);
  if (unitMatch) {
    const val = parseInt(unitMatch[1]);
    const unit = unitMatch[2].toLowerCase();
    if (unit === "s") return val * 1000;
    if (unit === "m") return val * 60 * 1000;
    if (unit === "h") return val * 3600 * 1000;
  }
  return null;
}

export function checkVoice(client, member, needPlaying = false) {
  if (!member.voice?.channel) {
    const container = new ContainerBuilder()
      .setAccentColor(client.theme)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`${Cross} You must be connected to a voice channel.`)
      );
    return { ok: false, container };
  }

  const botVoiceId = member.guild.members.me?.voice?.channelId;
  if (botVoiceId && botVoiceId !== member.voice.channel.id) {
    const container = new ContainerBuilder()
      .setAccentColor(client.theme)
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `${Cross} You must be in the same voice channel as me (<#${botVoiceId}>).`
        )
      );
    return { ok: false, container };
  }

  const player = client.riffy?.players.get(member.guild.id);
  if (needPlaying) {
    if (!player || !player.current) {
      const container = new ContainerBuilder()
        .setAccentColor(client.theme)
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(`${Warn} There is nothing currently playing.`)
        );
      return { ok: false, container };
    }
  }

  return { ok: true, player, channel: member.voice.channel };
}

export function makePlayerControlsRow(disabled = false) {
  const pauseResumeBtn = new ButtonBuilder()
    .setCustomId("music_pause_resume")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(PauseResume)
    .setDisabled(disabled);

  const skipBtn = new ButtonBuilder()
    .setCustomId("music_skip")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(Skip)
    .setDisabled(disabled);

  const likeBtn = new ButtonBuilder()
    .setCustomId("music_like")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(Heart)
    .setDisabled(disabled);

  const stopBtn = new ButtonBuilder()
    .setCustomId("music_stop")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(Stop)
    .setDisabled(disabled);

  return new ActionRowBuilder().addComponents(pauseResumeBtn, skipBtn, likeBtn, stopBtn);
}

export function makeSkipToButtonRow(skiptoId = "", disabled = false) {
  const customId = skiptoId ? `music_skipto_${skiptoId}` : "music_skipto";
  const skipToBtn = new ButtonBuilder()
    .setCustomId(customId)
    .setLabel("Play Now")
    .setStyle(ButtonStyle.Secondary)
    .setEmoji(Skip)
    .setDisabled(disabled);

  return new ActionRowBuilder().addComponents(skipToBtn);
}
