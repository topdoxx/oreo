import {
    ContainerBuilder,
    TextDisplayBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags
} from "discord.js";
import { cleft, cright } from "./emojis.js";

export async function paginator(target, items) {
    if (!items || items.length === 0) return;
    let page = 0;
    const client = target.client;

    const getComponents = () => {
        const actionRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId("previous")
                .setEmoji(cleft)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === 0),

            new ButtonBuilder()
                .setCustomId("next")
                .setEmoji(cright)
                .setStyle(ButtonStyle.Secondary)
                .setDisabled(page === items.length - 1)
        );

        return [
            new ContainerBuilder()
                .setAccentColor(client.theme)
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(items[page])
                )
                .addActionRowComponents(actionRow)
        ];
    };

    const replyOptions = {
        components: getComponents(),
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
    };

    let msg;
    if (target.isChatInputCommand?.() || target.isButton?.()) {
        msg = await target.reply(replyOptions);
        if (target.fetchReply) msg = await target.fetchReply();
    } else {
        msg = await target.reply(replyOptions);
    }

    const collector = msg.createMessageComponentCollector({
        time: 120000
    });

    collector.on("collect", async interaction => {
        const authorId = target.user?.id || target.author?.id;
        if (authorId && interaction.user.id !== authorId) {
            return interaction.reply({ content: "This menu is not for you.", flags: MessageFlags.Ephemeral });
        }

        if (interaction.customId === "previous" && page > 0) page--;
        if (interaction.customId === "next" && page < items.length - 1) page++;

        await interaction.update({
            components: getComponents()
        });
    });

    collector.on("end", async () => {
        try {
            const disabledRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId("previous")
                    .setEmoji(cleft)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true),

                new ButtonBuilder()
                    .setCustomId("next")
                    .setEmoji(cright)
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(true)
            );

            await msg.edit({
                components: [
                    new ContainerBuilder()
                        .setAccentColor(client.theme)
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(items[page])
                        )
                        .addActionRowComponents(disabledRow)
                ]
            });
        } catch { }
    });
}