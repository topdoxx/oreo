import { WebhookClient, EmbedBuilder } from "discord.js";

function getWebhook(url) {
  if (!url || typeof url !== "string" || !url.startsWith("https://")) return null;
  try {
    return new WebhookClient({ url });
  } catch {
    return null;
  }
}

export async function logGuildJoin(guild) {
  const url = process.env.WEBHOOK_GUILD_LOGS || process.env.WEBHOOK_SERVER_LOGS;
  const webhook = getWebhook(url);
  if (!webhook) return;

  try {
    const owner = await guild.fetchOwner().catch(() => null);
    const embed = new EmbedBuilder()
      .setTitle("Joined Server")
      .setColor(0x57f287)
      .addFields(
        { name: "Server Name", value: `${guild.name} (\`${guild.id}\`)`, inline: false },
        { name: "Owner", value: owner ? `${owner.user.tag} (\`${owner.id}\`)` : "Unknown", inline: true },
        { name: "Members", value: `${guild.memberCount}`, inline: true }
      )
      .setThumbnail(guild.iconURL({ size: 256 }) || null)
      .setTimestamp();
    await webhook.send({ embeds: [embed] }).catch(() => {});
  } catch {}
}

export async function logGuildLeave(guild) {
  const url = process.env.WEBHOOK_GUILD_LOGS || process.env.WEBHOOK_SERVER_LOGS;
  const webhook = getWebhook(url);
  if (!webhook) return;

  try {
    const embed = new EmbedBuilder()
      .setTitle("Left Server")
      .setColor(0xed4245)
      .addFields(
        { name: "Server Name", value: `${guild.name || "Unknown"} (\`${guild.id}\`)`, inline: false },
        { name: "Members", value: `${guild.memberCount || "Unknown"}`, inline: true }
      )
      .setThumbnail(guild.iconURL?.({ size: 256 }) || null)
      .setTimestamp();
    await webhook.send({ embeds: [embed] }).catch(() => {});
  } catch {}
}

export async function logCommandExecution(cmdName, user, guild, isSlash = false) {
  const url = process.env.WEBHOOK_COMMAND_LOGS;
  const webhook = getWebhook(url);
  if (!webhook) return;

  try {
    const embed = new EmbedBuilder()
      .setTitle("Command Executed")
      .setColor(0x5865f2)
      .addFields(
        { name: "Command", value: `\`${cmdName}\` (${isSlash ? "Slash" : "Prefix"})`, inline: true },
        { name: "User", value: `${user.tag} (\`${user.id}\`)`, inline: true },
        { name: "Server", value: guild ? `${guild.name} (\`${guild.id}\`)` : "Direct Message", inline: false }
      )
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .setTimestamp();
    await webhook.send({ embeds: [embed] }).catch(() => {});
  } catch {}
}

export async function logStatusEvent(status, details = "") {
  const url = process.env.WEBHOOK_STATUS_LOGS || process.env.WEBHOOK_CLIENT_LOGS;
  const webhook = getWebhook(url);
  if (!webhook) return;

  try {
    const isOnline = status.toLowerCase().includes("online");
    const embed = new EmbedBuilder()
      .setTitle(`Status: ${status}`)
      .setColor(isOnline ? 0x57f287 : 0xfee75c)
      .setDescription(details || `Bot status changed: **${status}**`)
      .setTimestamp();
    await webhook.send({ embeds: [embed] }).catch(() => {});
  } catch {}
}

